from sqlalchemy import Column, Integer, String, DateTime, create_engine
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class Deployment(Base):
    __tablename__ = "deployments"
    id = Column(Integer, primary_key=True)
    deployment_id = Column(String, unique=True)
    tool = Column(String)
    status = Column(String)
    duration = Column(Integer)
    created_at = Column(DateTime)