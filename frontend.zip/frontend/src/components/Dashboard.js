import React, { useEffect, useState } from "react";
import MetricsChart from "./MetricsChart"; // ✅ Import MetricsChart

function Dashboard() {
  const [deployments, setDeployments] = useState([]);

  useEffect(() => {
    // Fetch data from the backend API
    fetch("http://127.0.0.1:8000/deployments")
      .then((response) => response.json())
      .then((data) => setDeployments(data))
      .catch((error) => console.error("Error fetching deployments:", error));
  }, []);

  return (
    <div style={{ padding: "20px", fontFamily: "Arial, sans-serif", textAlign: "center" }}>
      <h2>DevOps Automation Metrics</h2>

      {/* ✅ Use MetricsChart and pass the data */}
      {deployments.length > 0 ? <MetricsChart data={deployments} /> : <p>Loading chart...</p>}

      <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "20px" }}>
        <thead>
          <tr style={{ background: "#4CAF50", color: "white", padding: "10px" }}>
            <th>ID</th>
            <th>Tool</th>
            <th>Status</th>
            <th>Duration (s)</th>
          </tr>
        </thead>
        <tbody>
          {deployments.length > 0 ? (
            deployments.map((deployment) => (
              <tr key={deployment.id} style={{ borderBottom: "1px solid #ddd" }}>
                <td>{deployment.id}</td>
                <td>{deployment.tool}</td>
                <td>{deployment.status}</td>
                <td>{deployment.duration}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="4" style={{ textAlign: "center", padding: "10px" }}>No data available</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

export default Dashboard;
