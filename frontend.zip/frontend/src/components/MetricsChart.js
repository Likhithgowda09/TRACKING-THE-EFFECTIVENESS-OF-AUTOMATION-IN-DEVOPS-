import React from "react";
import { Line } from "react-chartjs-2";
import { Chart, LineElement, CategoryScale, LinearScale, PointElement } from "chart.js";

// Register required Chart.js components
Chart.register(LineElement, CategoryScale, LinearScale, PointElement);

const MetricsChart = ({ data }) => {
  const chartData = {
    labels: data.map((item) => item.tool), // X-axis: DevOps tools
    datasets: [
      {
        label: "Execution Time (s)",
        data: data.map((item) => item.duration), // Y-axis: Execution time
        borderColor: "rgba(75,192,192,1)",
        backgroundColor: "rgba(75,192,192,0.2)",
        borderWidth: 2,
        fill: true,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: { beginAtZero: true },
    },
  };

  return (
    <div style={{ width: "100%", height: "300px", marginBottom: "20px" }}>
      <Line data={chartData} options={options} />
    </div>
  );
};

export default MetricsChart;
