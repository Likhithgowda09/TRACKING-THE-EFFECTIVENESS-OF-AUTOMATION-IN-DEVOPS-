import Dashboard from "./components/Dashboard";

function App() {
  return (
    <div>
      <h1>DevOps Automation Tracker</h1>
      <Dashboard />
    </div>
  );
}

export default App;